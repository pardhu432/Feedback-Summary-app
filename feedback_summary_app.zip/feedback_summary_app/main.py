import sys
from feedback_summary.ui import run

if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "data/feedback.json")
