"""Generates data/sample_feedback.csv and .json (seeded, reproducible).
40 valid rows (normal + boundary cases) + 4 intentionally invalid rows (CSV only)
so the bulk-import error log can be demonstrated."""
import csv, json, os, random

random.seed(84)
ROOT = os.path.join(os.path.dirname(__file__), "..", "data")

POS = {
 "Product": ["Great quality and durable, love it", "Excellent product, works perfectly", "Fantastic design and very sturdy"],
 "Service": ["Friendly staff and quick service", "Helpful team solved my problem fast", "Excellent customer service, very polite"],
 "Pricing": ["Great value for the price", "Affordable and good discounts", "Fair prices compared to others"],
 "Delivery": ["Fast delivery and well packaged", "Arrived early, great packaging", "Quick shipping, item in perfect condition"],
 "Store": ["Clean store and easy to find items", "Lovely layout, clean and organised", "Pleasant atmosphere and tidy shelves"]}
NEG = {
 "Product": ["Poor quality, broke after a week", "Product stopped working, very flimsy", "Cheap material and defective parts"],
 "Service": ["Rude staff and slow service", "Long wait and unhelpful team", "Slow response, nobody helped me"],
 "Pricing": ["Too expensive for the quality", "Overpriced and hidden charges", "Prices went up, not worth it"],
 "Delivery": ["Late delivery and damaged packaging", "Delivery was slow, package arrived damaged", "Order delayed again, poor tracking"],
 "Store": ["Crowded store and messy shelves", "Dirty floors and long queue at checkout", "Hard to find items, messy and crowded"]}
MID = ["It was okay, nothing special", "Average experience, could be better", "Decent but not outstanding"]
NAMES = ["Asha Rao","Vikram Singh","Meera Nair","Rahul Verma","Priya Iyer","Sanjay Gupta","Neha Kapoor",
         "Arjun Reddy","Kavya Menon","Rohan Das","Isha Patel","Aditya Joshi","Divya Sharma","Karan Malhotra"]
CATS = list(POS)

rows = []
months = ["2026-06","2026-07","2026-08","2026-09","2026-10","2026-11"]
for i in range(40):
    m = months[i * len(months) // 40]
    day = random.randint(1, 22)
    cat = random.choice(CATS)
    # later months drift lower for Delivery so the demo shows a warning/trend
    bias = -0.4 if (cat == "Delivery" and m >= "2026-09") else 0
    score = random.random() + bias
    if score > 0.55: rating, text = random.choice([4, 5, 5]), random.choice(POS[cat])
    elif score > 0.25: rating, text = 3, random.choice(MID)
    else: rating, text = random.choice([1, 1, 2]), random.choice(NEG[cat])
    rows.append({"date": f"{m}-{day:02d}", "customer": random.choice(NAMES), "category": cat,
                 "rating": rating, "comment": text})
# boundary cases
rows[0].update(rating=5, comment="Top!!")                       # shortest-ish comment
rows[1].update(rating=1, comment="Terrible. " + "Really bad experience overall. " * 5)  # long comment
rows.sort(key=lambda r: r["date"])

bad = [  # deliberately invalid rows (row-level errors)
 {"date": "2026-13-45", "customer": "Bad Date", "category": "Store", "rating": 4, "comment": "Invalid date row"},
 {"date": "2026-10-05", "customer": "Out Range", "category": "Product", "rating": 9, "comment": "Rating out of range"},
 {"date": "2026-10-06", "customer": "", "category": "Service", "rating": 3, "comment": "Missing customer name"},
 {"date": "2026-10-07", "customer": "Wrong Cat", "category": "Parking", "rating": 2, "comment": "Unknown category"},
]
fields = ["date", "customer", "category", "rating", "comment"]
with open(os.path.join(ROOT, "sample_feedback.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows + bad)
with open(os.path.join(ROOT, "sample_feedback.json"), "w", encoding="utf-8") as f:
    json.dump([{"id": i, **r} for i, r in enumerate(rows, 1)], f, indent=2)
print(f"wrote {len(rows)} valid + {len(bad)} invalid rows")
