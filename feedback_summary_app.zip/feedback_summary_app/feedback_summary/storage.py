"""JSON persistence with corruption recovery, atomic writes and CSV bulk import."""
import csv, json, os, shutil
from datetime import datetime
from .models import Feedback

CSV_FIELDS = ["id", "date", "customer", "category", "rating", "comment"]


class Store:
    def __init__(self, path="data/feedback.json"):
        self.path = path
        self.records: list[Feedback] = []
        self.load_notes: list[str] = []
        self.load()

    # ---- load / save ------------------------------------------------------
    def load(self):
        self.records, self.load_notes = [], []
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        try:
            with open(self.path, encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                raise json.JSONDecodeError("Top-level value must be a list", "", 0)
        except FileNotFoundError:
            self.save()
            self.load_notes.append("No data file found - created a clean one.")
            return
        except json.JSONDecodeError:
            bak = self.path + f".corrupt-{datetime.now():%Y%m%d%H%M%S}"
            shutil.copy(self.path, bak)
            self.save()
            self.load_notes.append(f"Data file was corrupted. Backed up to {bak}; started fresh.")
            return
        skipped = 0
        for item in raw:
            try:
                self.records.append(Feedback.from_dict(item))
            except (ValueError, TypeError, AttributeError):
                skipped += 1
        if skipped:
            self.load_notes.append(f"Skipped {skipped} invalid record(s) while loading.")

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump([r.to_dict() for r in self.records], f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)  # atomic: never leaves a half-written file

    # ---- CRUD -------------------------------------------------------------
    def next_id(self):
        return max((r.id for r in self.records), default=0) + 1

    def add(self, clean: dict):
        rec = Feedback(id=self.next_id(), **clean)
        self.records.append(rec)
        self.save()
        return rec

    def delete(self, rid):
        n = len(self.records)
        self.records = [r for r in self.records if r.id != rid]
        if len(self.records) != n:
            self.save()
            return True
        return False

    # ---- search -----------------------------------------------------------
    def search(self, keyword="", category=None, min_rating=1, max_rating=5):
        kw = keyword.lower().strip()
        out = []
        for r in self.records:
            if category and r.category != category:
                continue
            if not min_rating <= r.rating <= max_rating:
                continue
            if kw and kw not in r.comment.lower() and kw not in r.customer.lower():
                continue
            out.append(r)
        return out

    # ---- bulk import ------------------------------------------------------
    def import_csv(self, csv_path, log_path="exports/import_errors.log"):
        """Import rows; invalid rows are logged with row number + reason."""
        added, errors = 0, []
        try:
            with open(csv_path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                missing = {"date", "customer", "category", "rating", "comment"} - set(reader.fieldnames or [])
                if missing:
                    raise ValueError(f"Missing column(s): {', '.join(sorted(missing))}")
                for n, row in enumerate(reader, start=2):  # row 1 = header
                    try:
                        clean = Feedback.from_dict(row, id_=0).to_dict()
                        clean.pop("id")
                        self.records.append(Feedback(id=self.next_id(), **clean))
                        added += 1
                    except (ValueError, TypeError) as e:
                        errors.append(f"Row {n}: {e}")
        except FileNotFoundError:
            raise ValueError(f"File not found: {csv_path}")
        except UnicodeDecodeError:
            raise ValueError("File is not valid UTF-8 text")
        if added:
            self.save()
        if errors:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"Import of {csv_path} at {datetime.now():%Y-%m-%d %H:%M:%S}\n")
                f.write("\n".join(errors) + "\n")
        return added, errors

    def export_csv(self, path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            w.writeheader()
            for r in self.records:
                w.writerow(r.to_dict())
