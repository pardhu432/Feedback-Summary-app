"""Menu-driven terminal interface."""
import os, sys
from . import validation as v
from .analytics import warnings
from .reports import table, summary_lines, export_markdown, export_text, export_chart
from .storage import Store

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
def _c(text, code): return f"\033[{code}m{text}\033[0m" if USE_COLOR else text
def cyan(t): return _c(t, "36;1")
def red(t): return _c(t, "31;1")
def green(t): return _c(t, "32;1")
def yellow(t): return _c(t, "33;1")

BANNER = r"""
  ╔══════════════════════════════════════════════╗
  ║        ★  CUSTOMER FEEDBACK SUMMARY  ★       ║
  ║   Analyze ratings • Spot themes • Act fast   ║
  ╚══════════════════════════════════════════════╝"""

MENU = """
  1) Add feedback          6) Delete an entry
  2) View all feedback     7) Export reports (MD / TXT / CSV / chart)
  3) Search / filter       8) Bulk import from CSV
  4) Executive summary     9) Load sample dataset
  5) Warnings only         0) Exit
"""


def paginate(lines, page=15):
    head, body = lines[:2], lines[2:]
    for i in range(0, max(len(body), 1), page):
        print("\n".join(head + body[i:i + page]))
        if i + page < len(body):
            if input(f"-- {min(i + page, len(body))}/{len(body)} shown, Enter = more, q = stop -- ").lower() == "q":
                break


def add_entry(store):
    print(cyan("\n-- New feedback --"))
    clean = {"date": v.ask_date(), "customer": v.ask_customer(), "category": v.ask_category(),
             "rating": v.ask_rating(), "comment": v.ask_comment()}
    rec = store.add(clean)
    print(green(f"  ✓ Saved as #{rec.id}"))
    if rec.rating == 1:
        print(yellow("  ! 1-star review - consider following up with this customer."))


def view_all(store):
    if not store.records:
        return print("  No feedback yet.")
    paginate(table(sorted(store.records, key=lambda r: (r.date, r.id), reverse=True)))


def search(store):
    print(cyan("\n-- Search (leave blank to skip a filter) --"))
    kw = input("Keyword (comment/customer): ").strip()
    cat = None
    if input("Filter by category? (y/N): ").strip().lower() == "y":
        cat = v.ask_category()
    lo = v.ask_int("Min rating [1]: ", 1, 5, default=1)
    hi = v.ask_int("Max rating [5]: ", lo, 5, default=5)
    hits = store.search(kw, cat, lo, hi)
    print(f"\n  {len(hits)} match(es)")
    if hits:
        paginate(table(hits))


def show_summary(store):
    print(cyan("\n===== EXECUTIVE SUMMARY ====="))
    print("\n".join(summary_lines(store.records)))


def show_warnings(store):
    w = warnings(store.records)
    print(yellow("\n".join(f"  ! {x}" for x in w)) if w else green("  ✓ No warnings."))


def delete_entry(store):
    rid = v.ask_int("Entry ID to delete: ", 1, 10**9)
    rec = next((r for r in store.records if r.id == rid), None)
    if not rec:
        return print(red("  No entry with that ID."))
    print("\n".join(table([rec])))
    if input("Delete this entry? (y/N): ").strip().lower() == "y":
        store.delete(rid)
        print(green("  ✓ Deleted."))


def export_all(store):
    export_markdown(store.records, "exports/summary.md")
    export_text(store.records, "exports/audit_log.txt")
    store.export_csv("exports/feedback_report.csv")
    made = ["exports/summary.md", "exports/audit_log.txt", "exports/feedback_report.csv"]
    if export_chart(store.records, "exports/summary_chart.png"):
        made.append("exports/summary_chart.png")
    else:
        print(yellow("  (chart skipped: install matplotlib to enable)"))
    print(green("  ✓ Created: " + ", ".join(made)))


def bulk_import(store):
    path = input("Path to CSV (columns: date,customer,category,rating,comment): ").strip().strip('"')
    try:
        added, errs = store.import_csv(path)
    except ValueError as e:
        return print(red(f"  ✗ {e}"))
    print(green(f"  ✓ Imported {added} row(s)."))
    if errs:
        print(yellow(f"  {len(errs)} row(s) rejected - details in exports/import_errors.log"))
        for e in errs[:5]:
            print("   ", e)


def load_sample(store):
    sample = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "data", "sample_feedback.csv"))
    try:
        added, errs = store.import_csv(sample)
        print(green(f"  ✓ Loaded {added} sample rows ({len(errs)} rejected - deliberate bad rows)."))
    except ValueError as e:
        print(red(f"  ✗ {e}"))


ACTIONS = {"1": add_entry, "2": view_all, "3": search, "4": show_summary, "5": show_warnings,
           "6": delete_entry, "7": export_all, "8": bulk_import, "9": load_sample}


def run(data_path="data/feedback.json"):
    store = Store(data_path)
    print(cyan(BANNER))
    for note in store.load_notes:
        print(yellow("  ! " + note))
    print(f"  {len(store.records)} record(s) loaded from {data_path}")
    while True:
        try:
            print(MENU)
            choice = input("Choose an option: ").strip()
            if choice == "0":
                print("Goodbye!")
                return
            action = ACTIONS.get(choice)
            if action:
                action(store)
            else:
                print(red("  ✗ Please choose a number from the menu."))
        except (KeyboardInterrupt, EOFError):
            print("\nInterrupted - data is already saved. Goodbye!")
            return
