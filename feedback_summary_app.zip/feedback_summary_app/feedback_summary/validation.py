"""Defensive input validation: field rules + interactive prompt wrappers."""
from datetime import date, datetime

CATEGORIES = ["Product", "Service", "Pricing", "Delivery", "Store"]
RATING_MIN, RATING_MAX = 1, 5
NAME_MAX, COMMENT_MIN, COMMENT_MAX = 60, 3, 500


def validate_fields(date_str, customer, category, rating, comment):
    """Validate and normalise one record. Raises ValueError with a clear message."""
    # date
    try:
        d = datetime.strptime(str(date_str).strip(), "%Y-%m-%d").date()
    except ValueError:
        raise ValueError(f"Invalid date '{date_str}' (use YYYY-MM-DD)")
    if d > date.today():
        raise ValueError("Date cannot be in the future")
    # customer
    customer = " ".join(str(customer).split())
    if not customer:
        raise ValueError("Customer name is required")
    if len(customer) > NAME_MAX:
        raise ValueError(f"Customer name longer than {NAME_MAX} characters")
    # category (case-insensitive)
    match = next((c for c in CATEGORIES if c.lower() == str(category).strip().lower()), None)
    if match is None:
        raise ValueError(f"Invalid category '{category}' (choose: {', '.join(CATEGORIES)})")
    # rating
    try:
        r = int(str(rating).strip())
    except ValueError:
        raise ValueError(f"Rating '{rating}' is not a whole number")
    if not RATING_MIN <= r <= RATING_MAX:
        raise ValueError(f"Rating must be {RATING_MIN}-{RATING_MAX}, got {r}")
    # comment
    comment = " ".join(str(comment).split())
    if len(comment) < COMMENT_MIN:
        raise ValueError(f"Comment must be at least {COMMENT_MIN} characters")
    if len(comment) > COMMENT_MAX:
        raise ValueError(f"Comment longer than {COMMENT_MAX} characters")
    return {"date": d.isoformat(), "customer": customer, "category": match,
            "rating": r, "comment": comment}


# ---- interactive wrappers: loop until valid, never crash -------------------
def _read(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        raise KeyboardInterrupt


def ask_text(prompt, validator):
    """Ask until validator(value) doesn't raise ValueError."""
    while True:
        raw = _read(prompt)
        try:
            return validator(raw)
        except ValueError as e:
            print(f"  ✗ {e}")


def ask_date(prompt="Date (YYYY-MM-DD, blank = today): "):
    def val(raw):
        raw = raw or date.today().isoformat()
        return validate_fields(raw, "x", "Product", 3, "xxx")["date"]
    return ask_text(prompt, val)


def ask_customer(prompt="Customer name: "):
    return ask_text(prompt, lambda r: validate_fields("2000-01-01", r, "Product", 3, "xxx")["customer"])


def ask_category(prompt=None):
    opts = "  ".join(f"{i}) {c}" for i, c in enumerate(CATEGORIES, 1))
    print(f"  Categories: {opts}")

    def val(raw):
        if raw.isdigit() and 1 <= int(raw) <= len(CATEGORIES):
            return CATEGORIES[int(raw) - 1]
        return validate_fields("2000-01-01", "x", raw, 3, "xxx")["category"]
    return ask_text(prompt or "Category (number or name): ", val)


def ask_rating(prompt="Rating (1-5): "):
    return ask_text(prompt, lambda r: validate_fields("2000-01-01", "x", "Product", r, "xxx")["rating"])


def ask_comment(prompt="Comment: "):
    return ask_text(prompt, lambda r: validate_fields("2000-01-01", "x", "Product", 3, r)["comment"])


def ask_int(prompt, lo, hi, default=None):
    def val(raw):
        if raw == "" and default is not None:
            return default
        try:
            n = int(raw)
        except ValueError:
            raise ValueError("Please enter a whole number")
        if not lo <= n <= hi:
            raise ValueError(f"Enter a number between {lo} and {hi}")
        return n
    return ask_text(prompt, val)
