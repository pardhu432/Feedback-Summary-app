"""Console tables + Markdown / text / CSV / chart exports."""
import os
from datetime import datetime
from .analytics import summary

BAR = "█"


def bar(value, max_value, width=25):
    return BAR * (round(width * value / max_value) if max_value else 0)


def table(records):
    """Fixed-width table lines for a list of Feedback (first 2 lines = header)."""
    head = f"{'ID':>4} | {'Date':<10} | {'Customer':<16} | {'Category':<9} | {'★':^3} | Comment"
    lines = [head, "-" * 80]
    for r in records:
        cust = r.customer if len(r.customer) <= 16 else r.customer[:15] + "…"
        com = r.comment if len(r.comment) <= 32 else r.comment[:31] + "…"
        lines.append(f"{r.id:>4} | {r.date:<10} | {cust:<16} | {r.category:<9} | {r.rating:^3} | {com}")
    return lines


def summary_lines(records):
    s = summary(records)
    if not s["total"]:
        return ["No feedback recorded yet."]
    L = []
    L.append(f"Entries: {s['total']}   Average rating: {s['average']} / 5   "
             f"Period: {s['date_range'][0]} to {s['date_range'][1]}")
    se = s["sentiment"]
    L.append(f"Sentiment: {se['positive']} positive, {se['neutral']} neutral, {se['negative']} negative   "
             f"Trend: {s['trend']}")
    L += ["", "Rating distribution:"]
    mx = max(s["distribution"].values())
    for star, cnt in sorted(s["distribution"].items(), reverse=True):
        L.append(f"  {star}★ {bar(cnt, mx):<25} {cnt}")
    L += ["", "By category:", f"  {'Category':<10}{'Count':>6}{'Avg':>6}"]
    for cat, st in s["categories"].items():
        L.append(f"  {cat:<10}{st['count']:>6}{st['avg']:>6}")
    L += ["", "Most mentioned words: " + ", ".join(f"{w} ({n})" for w, n in s["keywords_all"])]
    L.append("  Praise themes:    " + (", ".join(w for w, _ in s["keywords_positive"]) or "-"))
    L.append("  Complaint themes: " + (", ".join(w for w, _ in s["keywords_negative"]) or "-"))
    L += ["", "Monthly trend:", f"  {'Month':<8}{'Count':>6}{'Avg':>6}"]
    for m, n, a in s["monthly"]:
        L.append(f"  {m:<8}{n:>6}{a:>6}  {bar(a, 5, 20)}")
    if s["warnings"]:
        L += ["", "WARNINGS:"] + [f"  ! {w}" for w in s["warnings"]]
    return L


def export_markdown(records, path):
    s = summary(records)
    md = ["# Customer Feedback Summary", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if not s["total"]:
        md.append("No feedback recorded.")
    else:
        md += [f"- **Entries:** {s['total']}", f"- **Average rating:** {s['average']} / 5",
               f"- **Period:** {s['date_range'][0]} to {s['date_range'][1]}",
               f"- **Trend:** {s['trend']}", "",
               "## Rating distribution", "| Stars | Count |", "|---|---|"]
        md += [f"| {k} | {n} |" for k, n in sorted(s["distribution"].items(), reverse=True)]
        md += ["", "## By category", "| Category | Count | Avg |", "|---|---|---|"]
        md += [f"| {c} | {v['count']} | {v['avg']} |" for c, v in s["categories"].items()]
        md += ["", "## Frequently mentioned words", "| Word | Mentions |", "|---|---|"]
        md += [f"| {w} | {n} |" for w, n in s["keywords_all"]]
        md += ["", "## Monthly trend", "| Month | Count | Avg |", "|---|---|---|"]
        md += [f"| {m} | {n} | {a} |" for m, n, a in s["monthly"]]
        if s["warnings"]:
            md += ["", "## Warnings"] + [f"- ⚠️ {w}" for w in s["warnings"]]
    _write(path, "\n".join(md) + "\n")


def export_text(records, path):
    _write(path, f"CUSTOMER FEEDBACK SUMMARY - {datetime.now():%Y-%m-%d %H:%M}\n"
                 + "=" * 60 + "\n" + "\n".join(summary_lines(records)) + "\n")


def export_chart(records, path):
    """Optional: needs matplotlib. Returns True/False."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False
    s = summary(records)
    if not s["total"]:
        return False
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].bar([str(k) for k in s["distribution"]], list(s["distribution"].values()), color="#4C78A8")
    ax[0].set(title="Rating distribution", xlabel="Stars", ylabel="Count")
    months = [m for m, _, _ in s["monthly"]]
    ax[1].plot(months, [a for _, _, a in s["monthly"]], marker="o", color="#E45756")
    ax[1].set(title="Average rating by month", ylim=(1, 5))
    ax[1].tick_params(axis="x", rotation=45)
    fig.tight_layout()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return True


def _write(path, text):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
