from dataclasses import dataclass, asdict
from .validation import validate_fields


@dataclass
class Feedback:
    id: int
    date: str
    customer: str
    category: str
    rating: int
    comment: str

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d, id_=None):
        clean = validate_fields(d.get("date"), d.get("customer"), d.get("category"),
                                d.get("rating"), d.get("comment"))
        rid = id_ if id_ is not None else d.get("id")
        return cls(id=int(rid), **clean)
