"""Core business logic: rating stats, keyword mining, trends, warnings."""
import re
from collections import Counter, defaultdict

STOPWORDS = set("""a an and are as at be been but by for from had has have i if in is it its me my
of on or our so that the their them they this to too was we were with you your very really just
would could should also than then there when what which who will not no yes can get got one all
into out up about after before over again more most some any much many ever even""".split())

POSITIVE_RATING, NEGATIVE_RATING = 4, 2
LOW_CATEGORY_AVG = 3.0


def avg(vals):
    vals = list(vals)
    return round(sum(vals) / len(vals), 2) if vals else 0.0


def rating_distribution(records):
    c = Counter(r.rating for r in records)
    return {star: c.get(star, 0) for star in range(1, 6)}


def category_stats(records):
    by = defaultdict(list)
    for r in records:
        by[r.category].append(r.rating)
    return {cat: {"count": len(v), "avg": avg(v)} for cat, v in sorted(by.items())}


def top_keywords(records, n=10, rating_filter=None):
    """Most frequent meaningful words. rating_filter: callable(rating)->bool."""
    words = Counter()
    for r in records:
        if rating_filter and not rating_filter(r.rating):
            continue
        for w in re.findall(r"[a-z']+", r.comment.lower()):
            w = w.strip("'")
            if len(w) > 2 and w not in STOPWORDS:
                words[w] += 1
    return words.most_common(n)


def monthly_trend(records):
    by = defaultdict(list)
    for r in records:
        by[r.date[:7]].append(r.rating)
    return [(m, len(v), avg(v)) for m, v in sorted(by.items())]


def sentiment_split(records):
    pos = sum(r.rating >= POSITIVE_RATING for r in records)
    neg = sum(r.rating <= NEGATIVE_RATING for r in records)
    return {"positive": pos, "neutral": len(records) - pos - neg, "negative": neg}


def trend_direction(records):
    t = monthly_trend(records)
    if len(t) < 2:
        return "not enough data"
    diff = round(t[-1][2] - t[-2][2], 2)
    if diff > 0.2:
        return f"improving (+{diff})"
    if diff < -0.2:
        return f"declining ({diff})"
    return f"stable ({diff:+})"


def warnings(records):
    """Threshold warning flags."""
    out = []
    if not records:
        return out
    overall = avg(r.rating for r in records)
    if overall < LOW_CATEGORY_AVG:
        out.append(f"Overall average rating is low ({overall}).")
    for cat, s in category_stats(records).items():
        if s["count"] >= 3 and s["avg"] < LOW_CATEGORY_AVG:
            out.append(f"Category '{cat}' averages {s['avg']} over {s['count']} reviews.")
    t = monthly_trend(records)
    if len(t) >= 2 and t[-1][2] - t[-2][2] <= -0.5:
        out.append(f"Rating dropped sharply in {t[-1][0]} ({t[-2][2]} -> {t[-1][2]}).")
    recent = sorted(records, key=lambda r: (r.date, r.id))[-10:]
    low = [r for r in recent if r.rating == 1]
    if len(low) >= 3:
        out.append(f"{len(low)} one-star reviews among the last 10 entries.")
    return out


def summary(records):
    n = len(records)
    return {
        "total": n,
        "average": avg(r.rating for r in records),
        "distribution": rating_distribution(records),
        "categories": category_stats(records),
        "sentiment": sentiment_split(records),
        "keywords_all": top_keywords(records, 10),
        "keywords_positive": top_keywords(records, 5, lambda x: x >= POSITIVE_RATING),
        "keywords_negative": top_keywords(records, 5, lambda x: x <= NEGATIVE_RATING),
        "monthly": monthly_trend(records),
        "trend": trend_direction(records),
        "warnings": warnings(records),
        "date_range": (min(r.date for r in records), max(r.date for r in records)) if n else None,
    }
