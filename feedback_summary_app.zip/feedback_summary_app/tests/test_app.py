import json, os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from feedback_summary.validation import validate_fields
from feedback_summary.storage import Store
from feedback_summary import analytics, reports

GOOD = dict(date_str="2026-01-10", customer="  Ann   Lee ", category="product", rating="4", comment="Nice item")


class TestValidation(unittest.TestCase):
    def test_normalises(self):
        r = validate_fields(**GOOD)
        self.assertEqual((r["customer"], r["category"], r["rating"]), ("Ann Lee", "Product", 4))

    def test_rejects_bad_input(self):
        for k, bad in [("date_str", "2026-02-30"), ("date_str", "2999-01-01"), ("customer", "  "),
                       ("category", "Parking"), ("rating", "abc"), ("rating", "0"), ("rating", "6"),
                       ("comment", "ab")]:
            with self.assertRaises(ValueError, msg=f"{k}={bad}"):
                validate_fields(**{**GOOD, k: bad})


class TestStorage(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.p = os.path.join(self.d, "f.json")

    def test_persistence_round_trip(self):
        s = Store(self.p); s.add(validate_fields(**GOOD))
        self.assertEqual(len(Store(self.p).records), 1)

    def test_corrupt_file_recovers(self):
        open(self.p, "w").write("{not json")
        s = Store(self.p)
        self.assertEqual(s.records, [])
        self.assertTrue(any("corrupted" in n for n in s.load_notes))

    def test_bulk_import_logs_errors(self):
        csvp = os.path.join(self.d, "i.csv")
        open(csvp, "w").write("date,customer,category,rating,comment\n"
                              "2026-01-01,A,Store,5,Lovely shop\n2026-01-02,B,Store,11,Bad rating\n")
        s = Store(self.p)
        added, errs = s.import_csv(csvp, log_path=os.path.join(self.d, "err.log"))
        self.assertEqual((added, len(errs)), (1, 1))
        self.assertIn("Row 3", errs[0])

    def test_search(self):
        s = Store(self.p)
        s.add(validate_fields("2026-01-01", "A", "Store", 5, "Lovely clean shop"))
        s.add(validate_fields("2026-01-02", "B", "Service", 1, "Rude staff"))
        self.assertEqual(len(s.search("rude")), 1)
        self.assertEqual(len(s.search(category="Store")), 1)
        self.assertEqual(len(s.search(max_rating=2)), 1)


class TestAnalytics(unittest.TestCase):
    def setUp(self):
        s = Store(os.path.join(tempfile.mkdtemp(), "f.json"))
        for d, cat, r, c in [("2026-01-05", "Delivery", 5, "fast delivery"), ("2026-01-06", "Delivery", 4, "fast shipping"),
                             ("2026-02-05", "Delivery", 1, "late delivery"), ("2026-02-06", "Delivery", 1, "late damaged"),
                             ("2026-02-07", "Delivery", 2, "slow delivery")]:
            s.add(validate_fields(d, "X", cat, r, c))
        self.recs = s.records

    def test_numbers(self):
        self.assertEqual(analytics.avg(r.rating for r in self.recs), 2.6)
        self.assertEqual(analytics.top_keywords(self.recs, 1)[0], ("delivery", 3))
        self.assertEqual(analytics.rating_distribution(self.recs)[1], 2)

    def test_warnings_and_exports(self):
        w = analytics.warnings(self.recs)
        self.assertTrue(any("Delivery" in x for x in w))
        self.assertTrue(any("dropped sharply" in x for x in w))
        out = os.path.join(tempfile.mkdtemp(), "s.md")
        reports.export_markdown(self.recs, out)
        self.assertIn("Frequently mentioned words", open(out, encoding="utf-8").read())

    def test_empty(self):
        self.assertEqual(reports.summary_lines([]), ["No feedback recorded yet."])


if __name__ == "__main__":
    unittest.main()
